#include<stdio.h>
#include<stdlib.h>

struct Node {
    int data;
    struct Node * next;
};

struct Node * createLinkedList(int a[], int n){
    struct Node * head = NULL;
    struct Node * curr = NULL;
    struct Node * temp = NULL;

    for(int i = 0 ; i < n ; i++){
        temp = (struct Node *) malloc(sizeof(struct Node));
        temp -> data = a[i];
        temp -> next = NULL;

        if(head == NULL){
            head = temp;
            curr = temp;
        }
        else {
            curr -> next = temp;
            curr = curr -> next;
        }
    }
    curr -> next = head;
    return head;
}

void printLinkedList(struct Node * head, int n){
    struct Node * temp = head;
    //printf("\nThe Doubly Linked List is --> \n");
    for(int i = 0 ; i < n ; i++){
        printf("%d\t", temp -> data);
        temp = temp -> next;
    }
    //printf("\n");
}

struct Node * predictWinner(struct Node * head, int n, int k){

    struct Node * prev = head;
    for(int i = 1 ; i < n ; i++){
        int counter = 0;
        while (counter < k){
            counter++;
            prev = head;
            head = head -> next;
        }
        prev -> next = head -> next;
        free(head);
        head = prev -> next;
    }
    return head;
}

int main(){

    int arr [] = {1, 2, 3, 4, 5, 6};
    int n = 6;
    int k = 2;

    // Create Linked List
    struct Node * head = createLinkedList(arr, n);
    
    printf("\n The Doubly Linked List is -> \n");
    printLinkedList(head, n);
    
    // Predict the Winner
    head = predictWinner(head, n, k);

    // Print Winning Node
    printf("\n The Winner Node is -> \n");
    printLinkedList(head, 1);
    printf("\n\n");
}
